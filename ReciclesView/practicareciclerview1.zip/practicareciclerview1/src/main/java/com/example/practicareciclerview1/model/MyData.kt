package com.example.practicareciclerview1.model

import android.icu.text.Transliterator.Position

class MyData(val position: Int,val colores: Map<String,String>) {
}